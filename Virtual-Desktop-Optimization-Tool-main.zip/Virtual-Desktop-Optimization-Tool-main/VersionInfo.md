# VDOT Version Information

Version information will be in the following format `2.0.2009.1`

- 2 - Major Revisions to `Windows_VDOT.ps1`
- 0 - Minor Revisions to `Windows_VDOT.ps1`
- 2009 - Supported version of Windows 10/11 configuration files
- 1 - Minor changes to configuration files

## Current Version

2.1.2009.1
## Change Log
- Added missing code that adds the time and date VDOT was run on a host to the registry

## Version History

2.0.2009.1

## Change Log
